#version 330 core

layout (location = 0) in ivec3 position;
layout (location = 1) in int state;

flat out int stateOut;


void main() {
    gl_Position = vec4((vec3(position) * 32.0) + 16.0, 1.0);
	stateOut = state;
}