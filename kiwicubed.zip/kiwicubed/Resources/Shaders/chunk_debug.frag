#version 330 core

out vec4 FragColor;

flat in int stateOutFrag;


void main()
{
	vec4 outColor = vec4(0.0, 0.0, 0.0, 1.0);
	if (stateOutFrag == 1) {
		outColor.x = 1.0;
	} else if (stateOutFrag == 2) {
		outColor.y = 1.0;
	} else if (stateOutFrag == 3) {
		outColor.z = 1.0;
	}
    FragColor = outColor;
}
