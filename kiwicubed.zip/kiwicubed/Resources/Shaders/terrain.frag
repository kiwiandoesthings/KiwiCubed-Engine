#version 430 core

out vec4 FragColor;

in vec3 blockPositionOut;
centroid in vec2 textureCoordinatesOut;

uniform sampler2D tex0;
uniform vec2 atlasSize;


void main() 
{
    vec3 tint = vec3(1.0, 1.0, 1.0);

    FragColor = texture(tex0, textureCoordinatesOut) * vec4(tint, 1.0);
}
