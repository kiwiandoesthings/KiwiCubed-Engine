#version 330 core

out vec4 FragColor;

in vec2 textureCoordinatesOut;

uniform sampler2D tex0;


void main()
{
	vec4 textureSample = texture(tex0, textureCoordinatesOut);
	//textureSample = vec4(1.0, 1.0, 1.0, textureSample.a);
	if (textureSample.a < 0.1) {
	//	discard;
	//	textureSample = vec4(0.0, 0.5, 0.6, 1.0);
	}
	textureSample.a = 1.0;

    FragColor = textureSample;
}