#version 330 core

layout (points) in;
layout (triangle_strip, max_vertices = 4) out;

flat in int stateOut[];
flat out int stateOutFrag;

uniform mat4 viewMatrix;
uniform mat4 projectionMatrix;
uniform float scale = 0.5;

void main() {
	vec3 right = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]);
    vec3 up = vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]);

    stateOutFrag = stateOut[0];
    vec3 center = gl_in[0].gl_Position.xyz;

    vec3 offsets[4] = vec3[](
		vec3(-1, -1, 0),
		vec3(-1,  1, 0),
		vec3( 1, -1, 0),
		vec3( 1,  1, 0)
	);

    for(int i = 0; i < 4; i++) {
        vec3 pos = center + (offsets[i].x * scale * right) + (offsets[i].y * scale * up);
        gl_Position = projectionMatrix * viewMatrix * vec4(pos, 1.0);
        EmitVertex();
    }
    EndPrimitive();
}